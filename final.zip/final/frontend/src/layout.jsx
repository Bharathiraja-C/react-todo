import React from "react";
import { Outlet } from "react-router-dom";
import Profile from "./Pages/Profile";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import Header from "./components/Menu";
import Login from "./Pages/signin";
const Layout = () => {
  return (
    <>
      <Outlet/>
    </>
  );
};

export default Layout;
