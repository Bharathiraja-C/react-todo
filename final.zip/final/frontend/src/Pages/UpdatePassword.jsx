// CreateUser.jsx
import React, { useState } from 'react';
import { Button, Alert, Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import UserService from '../Services/UserService'; // Import the UserService

const CreateUser = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [temppassword, setTempPassword] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const result = await UserService.updatePassword(email, temppassword,password);
            console.log('User created successfully:', result);
            // Handle success (e.g., show a success message)
            navigate('/');
        } catch (error) {
            console.error('Error creating user:', error);
            setError('please enter valid password');
            // Handle error (e.g., display an error message)
        }
    };

    return (
        <div className="form-head">
            <center className="create-user-head">Update Password</center>
            
            {error && <Alert variant="danger">{error}</Alert>} 
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                        type="email"
                        placeholder="Enter email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                </Form.Group>
                

                <Form.Group controlId="formBasicPassword">
                    <Form.Label>Temporary Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="Temporary Password"
                        value={temppassword}
                        onChange={(e) => setTempPassword(e.target.value)}
                    />
                </Form.Group>
                
                <Form.Group controlId="formBasicPassword1">
                    <Form.Label>New Password</Form.Label>
                    <Form.Control
                        type="password"
                        placeholder="New Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </Form.Group>

                
                <Button className="Button" type="submit">Update</Button>
                
            </Form>
        </div>
    );
};

export default CreateUser;
