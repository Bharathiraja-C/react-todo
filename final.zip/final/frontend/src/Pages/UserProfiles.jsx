import React, { useState, useEffect } from "react";
import UserService from "../Services/UserService";
import { Table, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import InputBase from '@mui/material/InputBase';
import { styled, alpha } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';
import "./userDetails.css";
const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: '20ch',
    },
  },
}));
const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  border: '1px solid #ccc', // Adding border
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  width: '50%', // Adjust width as per your requirement
  margin: '0 auto', // Center align
}));

const UserDetails = ({userId}) => {
  const [userDetails, setUserDetails] = useState({});
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const userData = await UserService.getUserProfiles(userId);
        setUserDetails(userData);
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [userId]);
  useEffect(()=>{
    console.log("userDetails",userDetails);
},[userDetails]);
const filteredUserDetails = Array.isArray(userDetails) ? userDetails.filter(userDetail => {
    return userDetail.username.toLowerCase().includes(searchTerm.toLowerCase());
}) : [];
const handleViewDetails = (userId) => {
    navigate(`/updateprofile/${userId}`);
  };
  return (
    <div className="div1">
      <h2 className="userD">User Details</h2>
      {userDetails && (
        <div>
            <Search>
          <SearchIconWrapper>
            <SearchIcon />
          </SearchIconWrapper>
          <StyledInputBase
            placeholder="Search…"
            inputProps={{ 'aria-label': 'search' }}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Search><br/>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Email</th>
                  <th className="table-header">Address</th>
                  <th className="table-header">Phone</th>
                  <th className="table-header">Role</th>
                  <th className="table-header">Designation</th>
                  <th className="table-header">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUserDetails.map((user, index) => (
                  <React.Fragment key={index}>
                      <tr>
                        <td>{user.username}</td>
                        <td>{user.email}</td>
                        <td>{user.address}</td>
                        <td>{user.phone}</td>
                        <td>{user.role}</td>
                        <td>{user.designation}</td>
                        <td>
                          <Button onClick={() => handleViewDetails(user.id)}>
                            Update
                          </Button>
                        </td>
                      </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No Users found</p>
          )}
        </div>
          )}

          
</div>
)}
export default UserDetails;
