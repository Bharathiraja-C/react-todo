import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Button } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";
import "./userDetails.css";

const ApproverPage = ({}) => {
  const [userDetails, setUserDetails] = useState({});
  const location = useLocation();
  const navigate = useNavigate();
  const project = location.state && location.state.project;
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if (project === "Approve Skills") {
          setUserDetails(await SkillService.getAllSkillDetails());
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [project]);

  const handleViewDetails = (skillId) => {
    navigate(`/users/${localStorage.getItem('userid')}/${skillId}`);

  };

  return (
    <div className="div1">
      {userDetails && project === "Approve Skills" && (
        <div>
          <h2 className="userD">Skill Details</h2>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Skill Name</th>
                  <th className="table-header">Proficiency Level</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                  <th className="table-header">Actions</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.map((userDetail, index) => (
                  userDetail.skills && userDetail.skills.status === "pending" && (
                    <React.Fragment key={index}>
                      <tr>
                        <td>{userDetail.skills.username}</td>
                        <td>{userDetail.skills.skillname}</td>
                        <td>{userDetail.skills.proficiencylevel}</td>
                        <td>{userDetail.skills.status}</td>
                        <td>
                          {new Date(userDetail.skills.createdat).toLocaleDateString()}
                        </td>
                        <td>
                          <Button onClick={() => handleViewDetails(userDetail.skills.id)}>
                            View Details
                          </Button>
                        </td>
                      </tr>
                    </React.Fragment>
                  )
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No skill details found</p>
          )}
        </div>
      )}
    </div>
  );
};

export default ApproverPage;
