import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import UserService from "../Services/UserService";

export default function Profile() {
  const [userData, setUserData] = useState(null);
  const [userId, setUserId] = useState(localStorage.getItem("userid"));

  useEffect(() => {
    async function fetchUserData() {
      try {
        const userData = await UserService.getUserData(userId);
        setUserData(userData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    }

    if (userId) {
      fetchUserData();
    }
  }, [userId]);

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "80vh",
      }}
    >
      <Card
        sx={{
          width: { xs: "90%", sm: "80%", md: "60%" },
          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
          borderRadius: 10,
          backgroundColor: "#f5f5dc",
        }}
      >
        <CardContent>
          <Typography
            variant="h5"
            component="div"
            sx={{ fontWeight: 600, textAlign: "center", mb: 2 }}
          >
            User Information
          </Typography>
          {userData && (
            <>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Username: {userData.username}
              </Typography>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Email: {userData.email}
              </Typography>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Address: {userData.address}
              </Typography>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Phone: {userData.phone}
              </Typography>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Role: {userData.role}
              </Typography>
              <Typography sx={{ mb: 1.5 }} variant="subtitle1" textAlign="center">
                Designation: {userData.designation}
              </Typography>
            </>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
