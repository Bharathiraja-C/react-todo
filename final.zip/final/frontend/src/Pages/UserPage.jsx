import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Button } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";
import "./userDetails.css";

const Projects = ({ userId }) => {
  const [userDetails, setUserDetails] = useState({});
  const location = useLocation();
  const project = location.state && location.state.project;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if(project==='Projects'){
          setUserDetails( await SkillService.getProjectDetails(userId));
        }
        else if (project==='Skills'){
          setUserDetails( await SkillService.getSkillDetails(userId));
        }
        else{
          setUserDetails( await SkillService.getCertificationDetails(userId));
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [project, userId]);

  return (
    <div className="div1">
      {userDetails && project==='Projects' && (
        <div>
          <h2 className="userD">Project Details</h2>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">Project Name</th>
                  <th className="table-header">Project Description</th>
                  <th className="table-header">Project Experience</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.map((project, index) => (
                  <React.Fragment key={index}>
                    <tr>
                      <td>{project.projectname}</td>
                      <td>{project.projectdescription}</td>
                      <td>{project.projectexperience}</td>
                      <td>{project.status}</td>
                      <td>
                        {new Date(project.createdat).toLocaleDateString()}
                      </td>
                    </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No projects found</p>
          )}
        </div>
      )}
      {userDetails && project==='Skills' && (
        <div>
          <h2 className="userD">Skill Details</h2>
          {userDetails && userDetails.length > 0 ? (
            <React.Fragment>
              <Table striped bordered hover>
                <thead>
                  <tr>
                    <th className="table-header">Skill Name</th>
                    <th className="table-header">Proficiency Level</th>
                    <th className="table-header">Status</th>
                    <th className="table-header">Submitted At</th>
                  </tr>
                </thead>
                <tbody>
                  {userDetails.map((skill, index) => (
                    <React.Fragment key={index}>
                      <tr>
                        <td>{skill.skillname}</td>
                        <td>{skill.proficiencylevel}</td>
                        <td>{skill.status}</td>
                        <td>{new Date(skill.createdat).toLocaleDateString()}</td>
                      </tr>
                    </React.Fragment>
                  ))}
                </tbody>
              </Table>
              <div className="button-container">
                <Button onClick={() => navigate(`/add-certifications/${userId}`)}>
                  Add Skills
                </Button>
              </div>
            </React.Fragment>
          ) : (
            <p>No skills found</p>
          )}
        </div>
      )}
      {userDetails && project==='Certifications' && (
        <div>
          <h2 className="userD">Certification Details</h2>
          {userDetails &&
          userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">Certification Name</th>
                  <th className="table-header">Certification File</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.map((certification, index) => (
                  <React.Fragment key={index}>
                      <tr>
                        <td>{certification.certificationname}</td>
                        <td>{certification.certificationfile}</td>
                        <td>{certification.status}</td>
                        <td>{new Date(certification.createdat).toLocaleDateString()}</td>
                      </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No certifications found</p>
          )}
          </div>
       )
    }
    </div>
  );
};

export default Projects;
