import React, { useState } from 'react';
import { Button, TextField, Typography, Grid } from '@mui/material';
import AuthService from '../Services/AuthService'; // Import the AuthService

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Call the AuthService to reset password
      await AuthService.resetPassword(email, otp, newPassword);
      // Reset form fields and show success message
      setEmail('');
      setOtp('');
      setNewPassword('');
      setError('');
      alert('Password reset successfully!');
    } catch (error) {
      console.error('Password reset failed:', error);
      setError('Failed to reset password. Please try again.');
    }
  };

  return (
    <Grid container justifyContent="center">
      <Grid item xs={12} sm={8} md={6} lg={4}>
        <div className="form-head">
          <center className="login-head">Forgot Password</center>
          <br />
          {error && <Typography variant="body1" color="error">{error}</Typography>}
          <form onSubmit={handleSubmit}>
            <TextField
              label="Email Address"
              type="email"
              fullWidth
              sx={{ mb: 2 }}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <TextField
              label="OTP"
              type="text"
              fullWidth
              sx={{ mb: 2 }}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              required
            />
            <TextField
              label="New Password"
              type="password"
              fullWidth
              sx={{ mb: 2 }}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
            <Button variant="contained" type="submit" fullWidth size="large">
              Submit
            </Button>
          </form>
        </div>
      </Grid>
    </Grid>
  );
};

export default ForgotPassword;
