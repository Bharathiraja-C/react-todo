import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import AuthService from "../Services/AuthService";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Call the AuthService to reset password
      await AuthService.resetPassword(email, otp, newPassword);
      // Reset form fields and show success message
      setEmail("");
      setOtp("");
      setNewPassword("");
      setError("");
      alert("Password reset successfully!");
    } catch (error) {
      console.error("Password reset failed:", error);
      setError("Failed to reset password. Please try again.");
    }
  };

  return (
    <div className="form-head">
      <center className="login-head">Forgot Password</center>
      <br />
      {error && <div className="alert alert-danger">{error}</div>}
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email Address</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group controlId="formBasicOtp">
          <Form.Label>OTP</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            required
          />
        </Form.Group>
        <Form.Group controlId="formBasicNewPassword">
          <Form.Label>New Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Enter new password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
        </Form.Group>
        <Button className="Button" type="submit">
          Submit
        </Button>
      </Form>
    </div>
  );
};

export default ForgotPassword;
