import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Form } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import InputBase from '@mui/material/InputBase';
import { styled, alpha } from '@mui/material/styles';
import SearchIcon from '@mui/icons-material/Search';
import "./userDetails.css";

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: '20ch',
    },
  },
}));

const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  border: '1px solid #ccc',
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  width: '80%',
  margin: '0 auto',
  [theme.breakpoints.up('md')]: {
    width: '50%',
  },
}));

const Adminpage = ({}) => {
  const [userDetails, setUserDetails] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const location = useLocation();
  const project = location.state && location.state.project;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if (project === "Projects") {
          setUserDetails(await SkillService.getAllProjectDetails());
        } else if (project === "Skills") {
          setUserDetails(await SkillService.getAllSkillDetails());
        } else if (project === "Certifications") {
          setUserDetails(await SkillService.getAllCertificationDetails());
        } else if(project === 'AddUser') {
          navigate("/create-user");
        }
        else{
          navigate('/userprofiles');
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [project, navigate]);

  const filteredProjectDetails = userDetails.filter(userDetail => {
    return userDetail.projects && userDetail.projects.projectname.toLowerCase().includes(searchTerm.toLowerCase());
  });
  const filteredSkillDetails = userDetails.filter(userDetail => {
    return userDetail.skills && userDetail.skills.skillname.toLowerCase().includes(searchTerm.toLowerCase());
  });
  const filteredCertificationDetails = userDetails.filter(userDetail => {
    return userDetail.certification && userDetail.certification.certificationname.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="div1">
      {userDetails && project === "Projects" && (
        <div>
          <h2 className="userD">Project Details</h2>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Search><br/>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Project Name</th>
                  <th className="table-header">Description</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {filteredProjectDetails.map((userDetail, index) => (
                  <tr key={index}>
                    <td>{userDetail.projects && userDetail.projects.username}</td>
                    <td>{userDetail.projects && userDetail.projects.projectname}</td>
                    <td>{userDetail.projects && userDetail.projects.projectdescription}</td>
                    <td>{userDetail.projects && userDetail.projects.status}</td>
                    <td>
                      {new Date( 
                        userDetail.projects &&
                        userDetail.projects.createdat
                      ).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No project details found</p>
          )}
        </div>
      )}
      {userDetails && project === "Skills" && (
        <div>
          <h2 className="userD">Skill Details</h2>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Search><br/>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Skill Name</th>
                  <th className="table-header">Proficiency Level</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {filteredSkillDetails.map((userDetail, index) => (
                  <tr key={index}>
                    <td>{userDetail.skills && userDetail.skills.username}</td>
                    <td>{userDetail.skills && userDetail.skills.skillname}</td>
                    <td>{userDetail.skills && userDetail.skills.proficiencylevel}</td>
                    <td>{userDetail.skills && userDetail.skills.status}</td>
                    <td>
                      {userDetail.skills && new Date(userDetail.skills.createdat).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No skill details found</p>
          )}
        </div>
      )}
      {userDetails && project === "Certifications" && (
        <div>
          <h2 className="userD">Certification Details</h2>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Search><br/>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Certification Name</th>
                  <th className="table-header">Certification File</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted on</th>
                </tr>
              </thead>
              <tbody>
                {filteredCertificationDetails.map((userDetail, index) => (
                  <tr key={index}>
                    <td>{userDetail.certification && userDetail.certification.username}</td>
                    <td>{userDetail.certification && userDetail.certification.certificationname}</td>
                    <td>{userDetail.certification && userDetail.certification.certificationfile}</td>
                    <td>{userDetail.certification && userDetail.certification.status}</td>
                    <td>
                      {new Date(userDetail.certification && userDetail.certification.createdat).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No certifications found</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Adminpage;
