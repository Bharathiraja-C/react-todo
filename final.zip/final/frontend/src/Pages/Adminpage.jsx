import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Form } from "react-bootstrap";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import "./userDetails.css";

const Adminpage = ({}) => {
  const [userDetails, setUserDetails] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const location = useLocation();
  const project = location.state && location.state.project;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if (project === "Projects") {
          setUserDetails(await SkillService.getAllProjectDetails());
        } else if (project === "Skills") {
          setUserDetails(await SkillService.getAllSkillDetails());
        } else if (project === "Certifications") {
          setUserDetails(await SkillService.getAllCertificationDetails());
        } else {
          navigate("/create-user");
        }
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [project]);

  // Filter user details based on search term
  const filteredUserDetails = userDetails.filter(userDetail => {
    // Assuming each user detail object has a skillname property
    return userDetail.skills && userDetail.skills.skillname.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="div1">
      {userDetails && project === "Projects" && (
        <div>
          <h2 className="userD">Project Details</h2>
          <Form.Group className="mb-3">
            <Form.Control
              type="text"
              placeholder="Search by skill name"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Form.Group>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Project Name</th>
                  <th className="table-header">Description</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {filteredUserDetails.map((userDetail, index) => (
                  <React.Fragment key={index}>
                    <tr>
                      <td>{userDetail.projects && userDetail.projects.username}</td>
                      <td>{userDetail.projects && userDetail.projects.projectname}</td>
                      <td>{userDetail.projects && userDetail.projects.projectdescription}</td>
                      <td>{userDetail.projects && userDetail.projects.status}</td>
                      <td>
                        {new Date( 
                          userDetail.projects &&
                          userDetail.projects.createdat
                        ).toLocaleDateString()}
                      </td>
                    </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No project details found</p>
          )}
        </div>
      )}
      {userDetails && project === "Skills" && (
        <div>
          <h2 className="userD">Skill Details</h2>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">User Name</th>
                  <th className="table-header">Skill Name</th>
                  <th className="table-header">Proficiency Level</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted At</th>
                </tr>
              </thead>
              <tbody>
                {filteredUserDetails.map((userDetail, index) => (
                  <React.Fragment key={index}>
                    <tr>
                    <td>{userDetail.skills && userDetail.skills.username}</td>
                <td>{userDetail.skills && userDetail.skills.skillname}</td>
                <td>{userDetail.skills && userDetail.skills.proficiencylevel}</td>
                <td>{userDetail.skills && userDetail.skills.status}</td>
                <td>
                  {userDetail.skills && new Date(userDetail.skills.createdat).toLocaleDateString()}
                </td>
                    </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No skill details found</p>
          )}
        </div>
      )}
      {userDetails && project === "Certifications" && (
        <div>
          <h2 className="userD">Certification Details</h2>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                <th className="table-header">User Name</th>
                  <th className="table-header">Certification Name</th>
                  <th className="table-header">Certification File</th>
                  <th className="table-header">Status</th>
                  <th className="table-header">Submitted on</th>
                </tr>
              </thead>
              <tbody>
                {filteredUserDetails.map((userDetails, index) => (
                  <React.Fragment key={index}>
                    <tr>
                    <td>{userDetails.certification && userDetails.certification.username}</td>
                      <td>{userDetails.certification && userDetails.certification.certificationname}</td>
                      <td>{userDetails.certification && userDetails.certification.certificationfile}</td>
                      <td>{userDetails.certification && userDetails.certification.status}</td>
                      <td>
                        {new Date(userDetails.certification && userDetails.certification.createdat).toLocaleDateString()}
                      </td>
                    </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No certifications found</p>
          )}
        </div>
      )}
    </div>
  );
};
export default Adminpage;
