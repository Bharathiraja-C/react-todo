import React, { useState,useEffect } from 'react';
import { Button, Form } from 'react-bootstrap';
import UserService from '../Services/UserService'; // Import UserService
import './Login.css';

const AddCertification = ({ userId }) => {
    const [skills, setSkills] = useState([]);
    useEffect(() => {
        addSkill();
    }, []);
    const handleSkillChange = (index, key, value) => {
        const updatedSkills = [...skills];
        updatedSkills[index][key] = value;
        setSkills(updatedSkills);
    };
    const handleProjectChange = (skillIndex, projectIndex, key, value) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].projects[projectIndex][key] = value;
        setSkills(updatedSkills);
    };
    const handleCertificationChange = (skillIndex, certificationIndex, key, value) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].certifications[certificationIndex][key] = value;
        setSkills(updatedSkills);
    };
    const addSkill = () => {
        setSkills([
            ...skills,
            { 
                id: Math.random().toString(36).substr(2, 9), 
                skillName: '', 
                proficiencyLevel: '',
                projects: [], // Initialize projects array
                certifications: [] // Initialize certifications array
            }
        ]);
    };

    const addProject = (skillIndex) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].projects.push({ 
            id: Math.random().toString(36).substr(2, 9), 
            projectName: '', 
            projectDescription: '', 
            projectExperience: ''
        });
        setSkills(updatedSkills);
    };

    const addCertification = (skillIndex) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].certifications.push({ 
            id: Math.random().toString(36).substr(2, 9), 
            certificationName: '', 
            certificationFile: ''
        });
        setSkills(updatedSkills);
    };

    const removeProject = (skillIndex, projectIndex) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].projects.splice(projectIndex, 1);
        setSkills(updatedSkills);
    };

    const removeCertification = (skillIndex, certificationIndex) => {
        const updatedSkills = [...skills];
        updatedSkills[skillIndex].certifications.splice(certificationIndex, 1);
        setSkills(updatedSkills);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const userData = { skills };
            await UserService.addCertification(userId, userData);
            console.log('Skills, Projects, and Certifications added successfully');
        } catch (error) {
            console.error('Error adding Skills, Projects, and Certifications:', error);
        }
    };
    const removeSkill = (index) => {
        const updatedSkills = [...skills];
        updatedSkills.splice(index, 1);
        setSkills(updatedSkills);
    };

    return (
        <div className="form-head">
            <center className="login-head">Tech Stack Details</center>
            <Form onSubmit={handleSubmit}>
                {skills.map((skill, skillIndex) => (
                    <div key={skill.id} >
                        <Form.Group controlId={`skillName${skillIndex}`}>
                            <Form.Label>Skill Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter skill name"
                                value={skill.skillName}
                                onChange={(e) => handleSkillChange(skillIndex, 'skillName', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`proficiencyLevel${skillIndex}`}>
                            <Form.Label>Proficiency Level</Form.Label>
                            <br />
                            <Form.Control
                                as="select"
                                value={skill.proficiencyLevel}
                                onChange={(e) => handleSkillChange(skillIndex, 'proficiencyLevel', e.target.value)}
                            >
                                <option value="">Select proficiency level</option>
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate">Intermediate</option>
                                <option value="Advanced">Advanced</option>
                            </Form.Control>
                        </Form.Group>
                        <br />
                        <div>
                            <label style={{ fontSize: "20px" }}>Add Project</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <Button variant="success" onClick={() => addProject(skillIndex)}>+</Button>
                        </div>
                        {skill.projects.map((project, projectIndex) => (
                            <div key={project.id}>
                                <Form.Group controlId={`projectName${projectIndex}`}>
                                    <Form.Label>Project Name</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter project name"
                                        value={project.projectName}
                                        onChange={(e) => handleProjectChange(skillIndex, projectIndex, 'projectName', e.target.value)}
                                    />
                                </Form.Group>
                                <Form.Group controlId={`projectDescription${projectIndex}`}>
                                    <Form.Label>Project Description</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter project description"
                                        value={project.projectDescription}
                                        onChange={(e) => handleProjectChange(skillIndex, projectIndex, 'projectDescription', e.target.value)}
                                    />
                                </Form.Group>
                                <Form.Group controlId={`projectExperience${projectIndex}`}>
                                    <Form.Label>Project Experience</Form.Label>
                                    <Form.Control
                                        type="text"
                                        placeholder="Enter project experience"
                                        value={project.projectExperience}
                                        onChange={(e) => handleProjectChange(skillIndex, projectIndex, 'projectExperience', e.target.value)}
                                    />
                                </Form.Group>
                                <Button variant="danger" onClick={() => removeProject(skillIndex, projectIndex)}>-</Button>
                           <br/> </div>
                        ))}
                        <br />
                        <div>
                            <label style={{ fontSize: "20px" }}>Add Certification</label>&nbsp;&nbsp;&nbsp;&nbsp;
                            <Button variant="success" onClick={() => addCertification(skillIndex)}>+</Button>
                        </div>

                        {skill.certifications.map((certification, certificationIndex) => (
                            <div key={certification.id}>
                                <Form.Group controlId={`certificationName${certificationIndex}`}>
                            <Form.Label>Certification Name</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter certification name"
                                value={certification.certificationName}
                                onChange={(e) => handleCertificationChange(skillIndex,certificationIndex, 'certificationName', e.target.value)}
                            />
                        </Form.Group>
                        <Form.Group controlId={`certificationFile${certificationIndex}`}>
                            <Form.Label>Certification File (Link or Drive)</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="Enter certification file link"
                                value={certification.certificationFile}
                                onChange={(e) => handleCertificationChange(skillIndex,certificationIndex, 'certificationFile', e.target.value)}
                            />
                        </Form.Group>
                                <Button variant="danger" onClick={() => removeCertification(skillIndex, certificationIndex)}>-</Button>
                                <br/>
                            </div>
                        ))}<Button variant="danger" onClick={() => removeSkill(skillIndex)}>-</Button>
                        <hr />
                    </div>
                    
                ))}
                <div>
    <br/>
    <Button variant="success" onClick={addSkill}>+</Button>
    </div>
    <br/> <Button type="submit">Submit</Button>
            </Form>
        </div>
    );
};

export default AddCertification;
