// services/UserService.js
import axios from 'axios';

const UserService = {
    async createUser(email, username, address, phone, role, designation) {
        try {
            const response = await axios.post('http://localhost:5000/api/create-user', { email, username, address, phone, role, designation });
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    },

    async updatePassword(email, temporaryPassword, newPassword) {
        try {
            const response = await axios.post('http://localhost:5000/api/update-password', {
                email,
                temporaryPassword,
                newPassword
            });
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    },

    async addCertification(userId, certificationData) {
        try {
            console.log('UserId:',userId)
            console.log('certificationData:',certificationData)
            const response = await axios.post(`http://localhost:5000/api/add-certifications/${userId}`, certificationData);
            return response.data;
        } catch (error) {
            throw error.response.data;
        }
    },
    async getUserDetails(skillId)  {
      try {
        // Make a fetch request to your backend API to fetch user details
        const response = await fetch(`http://localhost:5000/api/users-details/${skillId}`); // Replace '/api/users/${userId}' with your actual API endpoint
        if (!response.ok) {
          throw new Error('Failed to fetch user details');
        }
        console.log(response);
        const userData = await response.json();
        return userData;
      } catch (error) {
        console.error('Error fetching user details:', error);
        throw error;
      }
    },
    async updateUserStatus(userId,skillId, newStatus) {
        try {
            const response = await axios.post(`http://localhost:5000/api/users/${userId}/status`, {skillId:skillId, status: newStatus });
            return response.data;
        } catch (error) {
            console.error('Error updating user status:', error);
            throw error; 
        }
     },
     async UpdateProfiles(userId,email, username, address, phone, role, designation) {
        try {
            const response = await axios.post(`http://localhost:5000/api/updateprofiles`,{userId, email, username, address, phone, role, designation });
            return response.data;
        } catch (error) {
            console.error('Error updating user status:', error);
            throw error; 
        }
     },
     async getUserData(userId) {
        try {
            const response = await axios.post(`http://localhost:5000/api/profile/${userId}`);
            return response.data;
        } catch (error) {
            console.error('Error getting user status:', error);
            throw error; 
        }
     },
     async getUserProfiles() {
        try {
            const response = await axios.post(`http://localhost:5000/api/userprofiles`);
            return response.data;
        } catch (error) {
            console.error('Error getting user status:', error);
            throw error; 
        }
     }
  
};
export default UserService;
