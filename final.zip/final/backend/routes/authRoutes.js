// authRoutes.js
const express = require('express');
const router = express.Router();
const AuthController = require('../controllers/AuthController');
const UserController = require('../controllers/UserController');

const isAuthenticated = (req, res, next) => {
    const token = req.headers['access-token'];
    if (!token) {
        return res.status(401).json({ error: 'Unauthorized - No token provided' });
    }
}

router.post('/login', AuthController.login);

router.post('/checkAuth', AuthController.checkAuth);

router.post('/create-user',UserController.createUser);

router.post('/update-password', UserController.updatePassword);

router.post('/users/forgotPassword',AuthController.forgotPassword);

router.post('/users/resetPassword',AuthController.verifyOTP);
module.exports = router;
