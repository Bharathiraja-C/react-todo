const express = require('express');
const router = express.Router();
const CertificationController = require('../controllers/CertificationController');

router.get('/project-details/:userId', CertificationController.getProjectDetails);
router.get('/skill-details/:userId', CertificationController.getSkillDetails);
router.get('/certification-details/:userId', CertificationController.getCertificationDetails);
router.get('/allproject-details', CertificationController.getAllProjectDetails);
router.get('/allskill-details', CertificationController.getAllSkillDetails);
router.get('/allcertification-details', CertificationController.getAllCertificationDetails);

module.exports = router;